"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { MarketChart } from "@/components/market-chart"
import { Products } from "@/components/products"
import { QuoteForm } from "@/components/quote-form"
import { Features } from "@/components/features"
import { CTA } from "@/components/cta"
import { Footer } from "@/components/footer"

export default function Home() {
  const [selectedProducts, setSelectedProducts] = useState<Record<string, number>>({})

  const handleProductChange = (id: string, quantity: number) => {
    setSelectedProducts((prev) => ({
      ...prev,
      [id]: quantity,
    }))
  }

  const handleRemoveProduct = (id: string) => {
    setSelectedProducts((prev) => {
      const updated = { ...prev }
      delete updated[id]
      return updated
    })
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Products
        selectedProducts={selectedProducts}
        onProductChange={handleProductChange}
      />
      <MarketChart />
      <QuoteForm
        selectedProducts={selectedProducts}
        onRemoveProduct={handleRemoveProduct}
      />
      <Features />
      <CTA />
      <Footer />
    </main>
  )
}
