'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, Minus, ArrowLeft, ShoppingCart } from 'lucide-react'
import { products } from '@/components/products'
import { useCart } from '@/hooks/use-cart'

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = products.find((p) => p.id === params.id)
  const [quantity, setQuantity] = useState(0)
  const { addItem } = useCart()

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">Product Not Found</h1>
          <Link href="/">
            <Button>Return to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handleAddToCart = () => {
    if (quantity > 0) {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity,
        image: product.image,
      })
      setQuantity(0)
      alert('Product added to cart!')
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
          <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Products</span>
          </Link>
        </div>
      </div>

      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Image Gallery */}
            <div>
              <div className="relative h-96 w-full bg-card rounded-2xl border border-border overflow-hidden mb-6">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover"
                  priority
                />
              </div>
              {/* Additional images carousel (simulated) */}
              <div className="grid grid-cols-4 gap-4">
                {[0, 1, 2, 3].map((i) => (
                  <div key={i} className="relative h-24 bg-card rounded-lg border border-border overflow-hidden cursor-pointer hover:border-primary/50 transition-colors">
                    <Image
                      src={product.image}
                      alt={`${product.name} view ${i + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div>
              <div className="mb-6">
                <Badge className="mb-4 bg-secondary text-secondary-foreground">
                  {product.category}
                </Badge>
                <h1 className="text-4xl font-bold text-foreground mb-2">{product.name}</h1>
                <p className="text-muted-foreground text-lg">{product.description}</p>
              </div>

              {/* Price */}
              <div className="mb-8 pb-8 border-b border-border">
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-4xl font-bold text-primary">€{product.price}</span>
                  <span className="text-xl text-muted-foreground">per {product.unit}</span>
                </div>
                <p className="text-sm text-muted-foreground">Minimum order: {product.minQuantity} {product.unit}(s)</p>
              </div>

              {/* Product Specifications */}
              <div className="mb-8 pb-8 border-b border-border">
                <h3 className="text-lg font-semibold text-foreground mb-4">Product Specifications</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Product Name</span>
                    <span className="text-foreground font-medium">{product.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Category</span>
                    <span className="text-foreground font-medium">{product.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Unit Size</span>
                    <span className="text-foreground font-medium">{product.description}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Packaging</span>
                    <span className="text-foreground font-medium">{product.unit}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-8 pb-8 border-b border-border">
                <h3 className="text-lg font-semibold text-foreground mb-4">About This Product</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {product.id === 'coconut-oil' && 'Virgin organic coconut oil extracted from premium coconuts. Rich in medium-chain triglycerides and natural antioxidants. Perfect for food production, cosmetics, and industrial applications. Provides superior quality and sustainability.'}
                  {product.id === 'crude-palm-oil' && 'High-quality crude palm oil for bulk industrial use. Rich in vitamins A and E. Suitable for food manufacturing and oleochemical production. Reliable supply with consistent quality standards.'}
                  {product.id === 'refined-soybean-oil' && 'Premium refined soybean oil with superior purity and stability. Ideal for cooking oils, margarine production, and industrial applications. Certified quality meeting international food safety standards.'}
                  {product.id === 'fresh-potatoes' && 'Grade A fresh farm potatoes sourced from premium growing regions. Uniform size and consistent quality. Perfect for food service, restaurants, and retail distribution. Stored in optimal conditions to maintain freshness.'}
                  {product.id === 'fresh-ginger' && 'Bulk fresh premium ginger with aromatic spice profile. Hand-selected for quality and freshness. Ideal for food manufacturing, beverages, and culinary applications. Maintains natural flavor compounds.'}
                  {product.id === 'fresh-onion' && 'Yellow variety fresh onions with excellent shelf life. Sourced from trusted growers. Perfect for food processing, restaurants, and retail. Carefully handled to prevent bruising.'}
                  {product.id === 'garlic' && 'Premium quality fresh garlic with robust flavor profile. Perfect for culinary and food manufacturing applications. Long storage life with consistent potency. Ideal for bulk purchasing.'}
                  {product.id === 'eggs' && 'High-quality organic XL eggs from free-range hens. Carefully packed and maintained in optimal temperature. Meets all international food safety standards and certifications.'}
                  {product.id === 'sugar' && 'Pure refined beet sugar ideal for industrial and commercial use. Meets highest purity standards with consistent crystalline structure. Perfect for food and beverage manufacturing.'}
                  {product.id === 'sunflower-oil' && 'Cold-pressed premium sunflower oil rich in vitamins E and linoleic acid. Perfect for cooking and industrial applications. Eco-friendly and sustainable production practices.'}
                  {product.id === 'frozen-chicken' && 'Flash-frozen premium chicken breasts to lock in natural flavors and nutrients. Maintains quality throughout storage. Ideal for food service, restaurants, and retail sectors.'}
                  {product.id === 'frozen-vegetables' && 'Flash-frozen mixed vegetables maintaining natural taste and nutrients. Sourced from premium farms. Perfect for food service and retail distribution. Consistent quality in every package.'}
                </p>
              </div>

              {/* Quantity Selector */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-foreground mb-4">
                  Quantity ({product.unit})
                </label>
                <div className="flex items-center gap-4 mb-6">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(Math.max(product.minQuantity - 1, quantity - 1))}
                    disabled={quantity <= product.minQuantity - 1}
                    className="h-12 w-12"
                  >
                    <Minus className="w-5 h-5" />
                  </Button>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(product.minQuantity - 1, parseInt(e.target.value) || 0))}
                    className="w-20 text-center text-2xl font-bold bg-card border border-border rounded-lg px-3 py-2 text-foreground"
                    min={product.minQuantity - 1}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                    className="h-12 w-12"
                  >
                    <Plus className="w-5 h-5" />
                  </Button>
                </div>

                {/* Add to Cart Button */}
                <Button
                  onClick={handleAddToCart}
                  disabled={quantity === 0}
                  className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground py-6 text-lg font-semibold"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Add to Cart
                </Button>
              </div>

              {/* Contact Info */}
              <div className="bg-card border border-border rounded-xl p-6">
                <h4 className="font-semibold text-foreground mb-2">Need Help?</h4>
                <p className="text-muted-foreground text-sm mb-4">
                  Contact our sales team for bulk orders, custom requirements, or special pricing.
                </p>
                <a href="https://wa.me/33605547754" target="_blank" rel="noopener noreferrer">
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground">
                    Chat on WhatsApp
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
