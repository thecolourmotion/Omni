'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useCart } from '@/hooks/use-cart'
import { ArrowLeft, Trash2, Plus, Minus } from 'lucide-react'

export default function CartPage() {
  const { items, removeItem, updateQuantity, clearCart, total } = useCart()
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'payment' | 'confirmation'>('cart')
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    zipCode: '',
    country: 'France',
    cardName: '',
    cardNumber: '',
    cardExpiry: '',
    cardCVC: '',
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const isShippingValid = formData.firstName && formData.lastName && formData.email && formData.address && formData.city && formData.zipCode
  const isPaymentValid = formData.cardName && formData.cardNumber.length === 16 && formData.cardExpiry && formData.cardCVC.length === 3

  const handleCheckoutStep = (step: 'shipping' | 'payment' | 'confirmation') => {
    if (step === 'shipping' && !isShippingValid) {
      alert('Please fill all shipping details')
      return
    }
    if (step === 'payment' && !isPaymentValid) {
      alert('Please fill all payment details correctly')
      return
    }
    setCheckoutStep(step)
  }

  if (items.length === 0 && checkoutStep === 'cart') {
    return (
      <div className="min-h-screen bg-background">
        <div className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
            <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Products</span>
            </Link>
          </div>
        </div>

        <main className="pt-24 flex items-center justify-center pb-20">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-foreground mb-4">Your Cart is Empty</h1>
            <p className="text-muted-foreground mb-8">Start adding products to your cart</p>
            <Link href="/">
              <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground">
                Browse Products
              </Button>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
          <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Products</span>
          </Link>
        </div>
      </div>

      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Progress Steps */}
          <div className="mb-12 flex justify-between items-center">
            {['cart', 'shipping', 'payment', 'confirmation'].map((step, index) => (
              <div key={step} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${
                    checkoutStep === step || (index < ['cart', 'shipping', 'payment', 'confirmation'].indexOf(checkoutStep))
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-card border border-border text-muted-foreground'
                  }`}
                >
                  {index + 1}
                </div>
                {index < 3 && (
                  <div className={`flex-1 h-1 mx-2 rounded ${index < ['cart', 'shipping', 'payment', 'confirmation'].indexOf(checkoutStep) ? 'bg-primary' : 'bg-border'}`} />
                )}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Cart Items */}
              {checkoutStep === 'cart' && (
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-6">Shopping Cart</h2>
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div key={item.id} className="bg-card rounded-xl border border-border p-6 flex items-center gap-6">
                        <div className="relative w-20 h-20 flex-shrink-0">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            className="object-cover rounded-lg"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground">{item.name}</h3>
                          <p className="text-primary font-bold">€{item.price}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="h-9 w-9"
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="w-8 text-center font-semibold text-foreground">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="h-9 w-9"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-foreground">€{(item.price * item.quantity).toFixed(2)}</p>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.id)}
                            className="text-destructive hover:bg-destructive/10 mt-2"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button
                    variant="ghost"
                    onClick={clearCart}
                    className="text-destructive mt-6"
                  >
                    Clear Cart
                  </Button>
                </div>
              )}

              {/* Shipping */}
              {checkoutStep === 'shipping' && (
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-6">Shipping Information</h2>
                  <form className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="text"
                        name="firstName"
                        placeholder="First Name"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                      />
                      <Input
                        type="text"
                        name="lastName"
                        placeholder="Last Name"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <Input
                      type="email"
                      name="email"
                      placeholder="Email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                    <Input
                      type="tel"
                      name="phone"
                      placeholder="Phone Number"
                      value={formData.phone}
                      onChange={handleInputChange}
                      required
                    />
                    <Input
                      type="text"
                      name="company"
                      placeholder="Company Name (Optional)"
                      value={formData.company}
                      onChange={handleInputChange}
                    />
                    <Input
                      type="text"
                      name="address"
                      placeholder="Street Address"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="text"
                        name="city"
                        placeholder="City"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                      />
                      <Input
                        type="text"
                        name="zipCode"
                        placeholder="Zip Code"
                        value={formData.zipCode}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <select
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      className="w-full bg-input border border-border rounded-md px-3 py-2 text-foreground"
                    >
                      <option>France</option>
                      <option>Germany</option>
                      <option>UK</option>
                      <option>Spain</option>
                      <option>Italy</option>
                    </select>
                  </form>
                </div>
              )}

              {/* Payment */}
              {checkoutStep === 'payment' && (
                <div>
                  <h2 className="text-2xl font-bold text-foreground mb-6">Payment Information</h2>
                  <form className="space-y-4">
                    <Input
                      type="text"
                      name="cardName"
                      placeholder="Cardholder Name"
                      value={formData.cardName}
                      onChange={handleInputChange}
                      required
                    />
                    <Input
                      type="text"
                      name="cardNumber"
                      placeholder="Card Number (16 digits)"
                      maxLength={16}
                      value={formData.cardNumber}
                      onChange={(e) => handleInputChange({ ...e, target: { ...e.target, value: e.target.value.replace(/\D/g, '') } } as any)}
                      required
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="text"
                        name="cardExpiry"
                        placeholder="MM/YY"
                        maxLength={5}
                        value={formData.cardExpiry}
                        onChange={handleInputChange}
                        required
                      />
                      <Input
                        type="text"
                        name="cardCVC"
                        placeholder="CVC (3 digits)"
                        maxLength={3}
                        value={formData.cardCVC}
                        onChange={(e) => handleInputChange({ ...e, target: { ...e.target, value: e.target.value.replace(/\D/g, '') } } as any)}
                        required
                      />
                    </div>
                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground">
                        <strong>Demo Mode:</strong> This is a demonstration. No real payment processing occurs.
                      </p>
                    </div>
                  </form>
                </div>
              )}

              {/* Confirmation */}
              {checkoutStep === 'confirmation' && (
                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-2xl">✓</div>
                  </div>
                  <h2 className="text-3xl font-bold text-foreground mb-2">Order Confirmed!</h2>
                  <p className="text-muted-foreground mb-8">Thank you for your order. You will receive a confirmation email shortly.</p>
                  <div className="bg-card rounded-xl border border-border p-6 mb-8 text-left">
                    <h3 className="font-semibold text-foreground mb-4">Order Summary</h3>
                    <div className="space-y-2 text-sm">
                      <p>Order ID: <span className="text-primary font-mono">#OMN{Date.now()}</span></p>
                      <p>Total Amount: <span className="font-bold text-foreground">€{total.toFixed(2)}</span></p>
                      <p>Estimated Delivery: 5-7 business days</p>
                    </div>
                  </div>
                  <Link href="/">
                    <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground">
                      Back to Home
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-xl border border-border p-6 sticky top-24">
                <h3 className="text-lg font-semibold text-foreground mb-4">Order Summary</h3>
                
                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{item.name} x{item.quantity}</span>
                      <span className="text-foreground font-medium">€{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="text-foreground">€{total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span className="text-foreground">TBD</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-3 border-t border-border">
                    <span className="text-foreground">Total</span>
                    <span className="text-primary">€{total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  {checkoutStep === 'cart' && (
                    <Button
                      onClick={() => handleCheckoutStep('shipping')}
                      className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground"
                    >
                      Proceed to Shipping
                    </Button>
                  )}
                  {checkoutStep === 'shipping' && (
                    <Button
                      onClick={() => handleCheckoutStep('payment')}
                      className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground"
                    >
                      Proceed to Payment
                    </Button>
                  )}
                  {checkoutStep === 'payment' && (
                    <Button
                      onClick={() => handleCheckoutStep('confirmation')}
                      className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground"
                    >
                      Complete Order
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => setCheckoutStep('cart')}
                    className="w-full"
                  >
                    Back to Cart
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
