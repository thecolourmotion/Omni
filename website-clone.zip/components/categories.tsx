"use client"

import { Zap, Egg, Candy, Snowflake, Droplets } from "lucide-react"

const categories = [
  {
    icon: Zap,
    title: "Energy Drinks",
    description: "Red Bull, Monster, and more",
    color: "from-blue-500/20 to-blue-600/5",
    borderColor: "border-blue-500/30",
    iconColor: "text-blue-400",
  },
  {
    icon: Egg,
    title: "Eggs",
    description: "Organic, conventional, all sizes",
    color: "from-amber-500/20 to-amber-600/5",
    borderColor: "border-amber-500/30",
    iconColor: "text-amber-400",
  },
  {
    icon: Candy,
    title: "Sugar",
    description: "Beet, cane, bulk options",
    color: "from-pink-500/20 to-pink-600/5",
    borderColor: "border-pink-500/30",
    iconColor: "text-pink-400",
  },
  {
    icon: Snowflake,
    title: "Frozen Products",
    description: "Wide range of frozen goods",
    color: "from-cyan-500/20 to-cyan-600/5",
    borderColor: "border-cyan-500/30",
    iconColor: "text-cyan-400",
  },
  {
    icon: Droplets,
    title: "Sunflower Oil",
    description: "Premium, refined, bulk",
    color: "from-yellow-500/20 to-yellow-600/5",
    borderColor: "border-yellow-500/30",
    iconColor: "text-yellow-400",
  },
]

export function Categories() {
  return (
    <section id="categories" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            OUR CATEGORIES
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover our complete range of food products for professionals
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {categories.map((category) => (
            <div
              key={category.title}
              className={`group relative p-6 rounded-2xl bg-gradient-to-b ${category.color} border ${category.borderColor} backdrop-blur-sm hover:scale-105 transition-all duration-300 cursor-pointer`}
            >
              <div className={`w-14 h-14 rounded-xl bg-card flex items-center justify-center mb-4 ${category.iconColor}`}>
                <category.icon className="w-7 h-7" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{category.title}</h3>
              <p className="text-sm text-muted-foreground">{category.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
