"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus, Minus, Package } from "lucide-react"
import { useCart } from "@/hooks/use-cart"

export interface Product {
  id: string
  name: string
  description: string
  price: number
  unit: string
  category: string
  image: string
  minQuantity: number
}

const products: Product[] = [
  {
    id: "coconut-oil",
    name: "Coconut Oil",
    description: "Virgin organic",
    price: 4000,
    unit: "pallet",
    category: "Oil",
    image: "/images/coconut-oil.jpg",
    minQuantity: 1,
  },
  {
    id: "crude-palm-oil",
    name: "Crude Palm Oil",
    description: "Bulk supply",
    price: 1000,
    unit: "pallet",
    category: "Oil",
    image: "/images/crude-palm-oil.jpg",
    minQuantity: 1,
  },
  {
    id: "refined-soybean-oil",
    name: "Refined Soybean Oil",
    description: "Premium quality",
    price: 900,
    unit: "pallet",
    category: "Oil",
    image: "/images/refined-soybean-oil.jpg",
    minQuantity: 1,
  },
  {
    id: "fresh-potatoes",
    name: "Fresh Farm Potatoes",
    description: "Grade A quality",
    price: 300,
    unit: "pallet",
    category: "Food",
    image: "/images/fresh-potatoes.jpg",
    minQuantity: 1,
  },
  {
    id: "fresh-ginger",
    name: "Bulk Fresh Ginger",
    description: "Premium organic",
    price: 1800,
    unit: "pallet",
    category: "Food",
    image: "/images/fresh-ginger.jpg",
    minQuantity: 1,
  },
  {
    id: "fresh-onion",
    name: "Fresh Onion",
    description: "Yellow variety",
    price: 350,
    unit: "pallet",
    category: "Food",
    image: "/images/fresh-onion.jpg",
    minQuantity: 1,
  },
  {
    id: "garlic",
    name: "Garlic",
    description: "Fresh premium",
    price: 800,
    unit: "pallet",
    category: "Food",
    image: "/images/garlic.jpg",
    minQuantity: 1,
  },
  {
    id: "eggs",
    name: "Organic XL Eggs",
    description: "Carton 360 units",
    price: 145,
    unit: "pallet",
    category: "Eggs",
    image: "/images/eggs.jpg",
    minQuantity: 1,
  },
  {
    id: "sugar",
    name: "Beet Sugar",
    description: "25kg bag",
    price: 32,
    unit: "pallet",
    category: "Sugar",
    image: "/images/sugar.jpg",
    minQuantity: 1,
  },
  {
    id: "sunflower-oil",
    name: "Sunflower Oil",
    description: "Pallet 1L",
    price: 1134,
    unit: "pallet",
    category: "Oil",
    image: "/images/sunflower-oil.jpg",
    minQuantity: 1,
  },
  {
    id: "frozen-chicken",
    name: "Frozen Chicken Breasts",
    description: "Carton 10kg",
    price: 450,
    unit: "pallet",
    category: "Frozen",
    image: "/images/frozen-chicken.jpg",
    minQuantity: 1,
  },
  {
    id: "frozen-vegetables",
    name: "Frozen Mixed Vegetables",
    description: "Carton 10kg",
    price: 380,
    unit: "pallet",
    category: "Frozen",
    image: "/images/frozen-vegetables.jpg",
    minQuantity: 1,
  },
]

interface ProductCardProps {
  product: Product
  quantity: number
  onQuantityChange: (id: string, quantity: number) => void
}

function ProductCard({ product, quantity, onQuantityChange }: ProductCardProps) {
  return (
    <div className="bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 transition-all">
      <Link href={`/products/${product.id}`}>
        <div className="relative h-48 w-full bg-muted">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
      </Link>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="font-semibold text-foreground mb-1">{product.name}</h3>
            <p className="text-sm text-muted-foreground">{product.description}</p>
          </div>
          <Badge variant="secondary" className="bg-secondary text-secondary-foreground whitespace-nowrap ml-2">
            {product.category}
          </Badge>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-2xl font-bold text-primary">€{product.price}</span>
            <span className="text-sm text-muted-foreground">/{product.unit}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 mb-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => onQuantityChange(product.id, Math.max(0, quantity - 1))}
            disabled={quantity === 0}
            className="h-10 w-10"
          >
            <Minus className="w-4 h-4" />
          </Button>
          <span className="w-12 text-center font-semibold text-foreground">{quantity}</span>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onQuantityChange(product.id, quantity + 1)}
            className="h-10 w-10"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <Link href={`/products/${product.id}`} className="w-full">
          <Button variant="outline" className="w-full">
            View Details
          </Button>
        </Link>
      </div>
    </div>
  )
}

interface ProductsProps {
  selectedProducts: Record<string, number>
  onProductChange: (id: string, quantity: number) => void
}

export function Products({ selectedProducts, onProductChange }: ProductsProps) {
  return (
    <section id="products" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Package className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">MINIMUM 10 PALLETS</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            PRODUCT CATALOG
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Select your products to generate a personalized quote or click any product for more details
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              quantity={selectedProducts[product.id] || 0}
              onQuantityChange={onProductChange}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

export { products }
