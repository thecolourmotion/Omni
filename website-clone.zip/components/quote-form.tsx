"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, AlertCircle, CheckCircle, X } from "lucide-react"
import { products } from "@/components/products"

const countries = [
  "United States", "United Kingdom", "Germany", "France", "Belgium", "Spain", "Italy", 
  "Netherlands", "Portugal", "Switzerland", "Canada", "Australia", "Other"
]

interface QuoteFormProps {
  selectedProducts: Record<string, number>
  onRemoveProduct: (id: string) => void
}

export function QuoteForm({ selectedProducts, onRemoveProduct }: QuoteFormProps) {
  const [formData, setFormData] = useState({
    company: "",
    contact: "",
    email: "",
    phone: "",
    country: "",
    language: "en",
  })

  const selectedItems = products.filter((p) => selectedProducts[p.id] > 0)
  const totalPalettes = Object.values(selectedProducts).reduce((sum, qty) => sum + qty, 0)
  const subtotal = selectedItems.reduce(
    (sum, p) => sum + p.price * selectedProducts[p.id],
    0
  )
  const tax = subtotal * 0.2
  const total = subtotal + tax

  const isValid = totalPalettes >= 10 && 
    formData.company && 
    formData.contact && 
    formData.email && 
    formData.phone && 
    formData.country

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!isValid) return
    alert("Quote generated successfully! A confirmation email will be sent to you.")
  }

  return (
    <section id="quote" className="py-20 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            WHOLESALE QUOTE REQUEST
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get a personalized offer for your bulk orders (minimum 10 pallets)
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Selected Products */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Select Your Products
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedItems.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No products selected</p>
                  <p className="text-sm mt-2">
                    Add products from the catalog above
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {selectedItems.map((product) => (
                    <div
                      key={product.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 border border-border"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{product.image}</span>
                        <div>
                          <p className="font-medium text-foreground">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {selectedProducts[product.id]} × €{product.price}/{product.unit}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-semibold text-primary">
                          €{(product.price * selectedProducts[product.id]).toLocaleString()}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onRemoveProduct(product.id)}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Form and Summary */}
          <div className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground">Your Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="company" className="text-foreground">
                        Company Name *
                      </Label>
                      <Input
                        id="company"
                        value={formData.company}
                        onChange={(e) =>
                          setFormData({ ...formData, company: e.target.value })
                        }
                        className="bg-input border-border text-foreground"
                        placeholder="Your company"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact" className="text-foreground">
                        Contact Name *
                      </Label>
                      <Input
                        id="contact"
                        value={formData.contact}
                        onChange={(e) =>
                          setFormData({ ...formData, contact: e.target.value })
                        }
                        className="bg-input border-border text-foreground"
                        placeholder="Your name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-foreground">
                        Email *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        className="bg-input border-border text-foreground"
                        placeholder="email@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-foreground">
                        Phone *
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="bg-input border-border text-foreground"
                        placeholder="+1 555 000 0000"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country" className="text-foreground">
                        Delivery Country *
                      </Label>
                      <Select
                        value={formData.country}
                        onValueChange={(value) =>
                          setFormData({ ...formData, country: value })
                        }
                      >
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          {countries.map((country) => (
                            <SelectItem key={country} value={country}>
                              {country}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="language" className="text-foreground">
                        Quote Language
                      </Label>
                      <Select
                        value={formData.language}
                        onValueChange={(value) =>
                          setFormData({ ...formData, language: value })
                        }
                      >
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="fr">Français</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Summary */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground">Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Selected Pallets</span>
                  <Badge
                    variant={totalPalettes >= 10 ? "default" : "destructive"}
                    className={totalPalettes >= 10 ? "bg-primary text-primary-foreground" : ""}
                  >
                    {totalPalettes} pallets
                  </Badge>
                </div>

                {totalPalettes < 10 && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                    <AlertCircle className="w-4 h-4 text-destructive" />
                    <span className="text-sm text-destructive">
                      Minimum 10 pallets required
                    </span>
                  </div>
                )}

                {totalPalettes >= 10 && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 border border-primary/20">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span className="text-sm text-primary">
                      Minimum reached
                    </span>
                  </div>
                )}

                <div className="border-t border-border pt-4 space-y-2">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal (excl. tax)</span>
                    <span>€{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Tax (20%)</span>
                    <span>€{tax.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-foreground pt-2 border-t border-border">
                    <span>Total (incl. tax)</span>
                    <span className="text-primary">€{total.toLocaleString()}</span>
                  </div>
                </div>

                <Button
                  onClick={handleSubmit}
                  disabled={!isValid}
                  className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground py-6 text-lg disabled:opacity-50"
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Generate PDF Quote
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
