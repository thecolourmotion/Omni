"use client"

import { useState, useEffect } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { TrendingUp, TrendingDown } from "lucide-react"

const commodities = [
  { id: "coconut-oil", name: "Coconut Oil", price: 4000, change: 15.42, unit: "€/pallet", color: "#eab308" },
  { id: "crude-palm-oil", name: "Crude Palm Oil", price: 1000, change: 18.93, unit: "€/pallet", color: "#f97316" },
  { id: "refined-soybean-oil", name: "Refined Soybean Oil", price: 900, change: 22.57, unit: "€/pallet", color: "#ec4899" },
  { id: "fresh-potatoes", name: "Fresh Potatoes", price: 300, change: 19.26, unit: "€/pallet", color: "#3b82f6" },
  { id: "fresh-ginger", name: "Fresh Ginger", price: 1800, change: 12.89, unit: "€/pallet", color: "#06b6d4" },
]

// Generate fake chart data with upward trend
function generateChartData() {
  return Array.from({ length: 24 }, (_, i) => {
    const hour = i
    const data: Record<string, number | string> = { time: `${hour}:00` }
    commodities.forEach((c) => {
      const baseValue = c.price
      // Create upward trend with slight variation
      const trendFactor = (i / 24) * baseValue * 0.15
      const variation = (Math.random() - 0.3) * baseValue * 0.08
      data[c.id] = +(baseValue + trendFactor + variation).toFixed(4)
    })
    return data
  })
}

export function MarketChart() {
  const [chartData, setChartData] = useState<Record<string, number | string>[]>([])
  const [selectedCommodity, setSelectedCommodity] = useState<string | null>(null)
  const [currentTime, setCurrentTime] = useState("")

  useEffect(() => {
    setChartData(generateChartData())
    setCurrentTime(new Date().toLocaleTimeString("en-US"))
    
    const interval = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString("en-US"))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <section id="market" className="py-20 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Commodity Prices
          </h2>
          <p className="text-muted-foreground">
            24-hour evolution - Indicative data
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Updated: {currentTime}
          </p>
        </div>

        {/* Commodity Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {commodities.map((commodity) => (
            <button
              key={commodity.id}
              onClick={() =>
                setSelectedCommodity(
                  selectedCommodity === commodity.id ? null : commodity.id
                )
              }
              className={`p-4 rounded-xl border transition-all ${
                selectedCommodity === commodity.id || selectedCommodity === null
                  ? "bg-card border-border opacity-100"
                  : "bg-card/50 border-border/50 opacity-50"
              } hover:border-primary/50`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">{commodity.name}</span>
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: commodity.color }}
                />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-bold text-foreground">
                  {commodity.price.toLocaleString()}
                </span>
                <span
                  className={`text-sm flex items-center gap-1 ${
                    commodity.change >= 0 ? "text-green-400" : "text-red-400"
                  }`}
                >
                  {commodity.change >= 0 ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {commodity.change >= 0 ? "+" : ""}
                  {commodity.change}%
                </span>
              </div>
              <span className="text-xs text-muted-foreground">{commodity.unit}</span>
            </button>
          ))}
        </div>

        {/* Chart */}
        <div className="bg-card rounded-2xl border border-border p-6">
          <div className="h-[300px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis
                  dataKey="time"
                  stroke="#888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  width={60}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1a1a2e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                  labelStyle={{ color: "#fff" }}
                />
                {commodities.map((commodity) => (
                  <Line
                    key={commodity.id}
                    type="monotone"
                    dataKey={commodity.id}
                    stroke={commodity.color}
                    strokeWidth={2}
                    dot={false}
                    opacity={
                      selectedCommodity === null ||
                      selectedCommodity === commodity.id
                        ? 1
                        : 0.1
                    }
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-center text-xs text-muted-foreground mt-4">
            Click on a product to isolate its curve - Variation in % compared to reference price
          </p>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          * Indicative data based on global market trends. Not financial advice.
        </p>
      </div>
    </section>
  )
}
