"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Phone, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { items } = useCart()

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <Image
              src="/images/logo.png"
              alt="Omnisourcegroup Logo"
              width={40}
              height={40}
              className="w-10 h-10"
            />
            <span className="font-bold text-xl text-foreground">Omnisourcegroup</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#products" className="text-muted-foreground hover:text-foreground transition-colors">
              Products
            </Link>
            <Link href="#categories" className="text-muted-foreground hover:text-foreground transition-colors">
              Categories
            </Link>
            <Link href="#market" className="text-muted-foreground hover:text-foreground transition-colors">
              Markets
            </Link>
            <Link href="#quote" className="text-muted-foreground hover:text-foreground transition-colors">
              Quote
            </Link>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a href="https://wa.me/33605547754" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
              <Phone className="w-4 h-4" />
              <span>+33 6 05 54 77 54</span>
            </a>
            <Link href="/cart" className="relative">
              <Button variant="ghost" size="icon" className="text-foreground hover:bg-card">
                <ShoppingCart className="w-5 h-5" />
                {items.length > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-primary rounded-full text-xs text-white flex items-center justify-center font-bold">
                    {items.length}
                  </span>
                )}
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground">
                Register
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-card border-t border-border">
              <nav className="flex flex-col px-4 py-4 gap-4">
                <Link href="#products" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                  Products
                </Link>
                <Link href="#categories" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                  Categories
                </Link>
                <Link href="#market" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                  Markets
                </Link>
                <Link href="#quote" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                  Quote
                </Link>
                <a href="https://wa.me/33605547754" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground py-2">
                  <Phone className="w-4 h-4" />
                  <span>+33 6 05 54 77 54</span>
                </a>
                <Link href="/cart" className="flex items-center gap-2 text-muted-foreground py-2">
                  <ShoppingCart className="w-4 h-4" />
                  <span>Cart {items.length > 0 && `(${items.length})`}</span>
                </Link>
                <Link href="/register" className="w-full">
                  <Button className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-primary-foreground w-full">
                    Register
                  </Button>
                </Link>
              </nav>
            </div>
          )}
    </header>
  )
}
