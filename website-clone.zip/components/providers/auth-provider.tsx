'use client';

import { useEffect, useState, ReactNode } from 'react';
import { AuthContext, User } from '@/hooks/use-auth';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check if user is logged in on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('omnisource-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Failed to load user:', e);
      }
    }
    setIsLoading(false);
  }, []);

  const register = async (email: string, name: string, password: string) => {
    // Simple validation
    if (!email || !name || !password) {
      throw new Error('All fields are required');
    }

    // Check if user already exists
    const existingUsers = JSON.parse(localStorage.getItem('omnisource-users') || '[]');
    if (existingUsers.some((u: any) => u.email === email)) {
      throw new Error('Email already registered');
    }

    // Create new user (in production, this would hash the password)
    const newUser = {
      id: Date.now().toString(),
      email,
      name,
      password: btoa(password), // Simple base64 encoding (NOT secure for production)
    };

    existingUsers.push(newUser);
    localStorage.setItem('omnisource-users', JSON.stringify(existingUsers));

    const loggedInUser: User = { id: newUser.id, email, name };
    setUser(loggedInUser);
    localStorage.setItem('omnisource-user', JSON.stringify(loggedInUser));
  };

  const login = async (email: string, password: string) => {
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    const users = JSON.parse(localStorage.getItem('omnisource-users') || '[]');
    const foundUser = users.find(
      (u: any) => u.email === email && u.password === btoa(password)
    );

    if (!foundUser) {
      throw new Error('Invalid email or password');
    }

    const loggedInUser: User = {
      id: foundUser.id,
      email: foundUser.email,
      name: foundUser.name,
    };
    setUser(loggedInUser);
    localStorage.setItem('omnisource-user', JSON.stringify(loggedInUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('omnisource-user');
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
