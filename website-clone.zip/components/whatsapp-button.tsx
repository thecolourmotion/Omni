'use client';

import { MessageCircle } from 'lucide-react';

export function WhatsAppButton() {
  const whatsappNumber = '+33605547754';
  const whatsappLink = `https://wa.me/${whatsappNumber.replace(/\D/g, '')}`;

  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 bg-gradient-to-r from-primary to-secondary rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 group"
      title="Chat with us on WhatsApp"
    >
      <MessageCircle className="w-7 h-7 text-white group-hover:animate-bounce" />
      
      {/* Tooltip */}
      <div className="absolute bottom-full right-0 mb-3 px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none shadow-md">
        Chat with us!
      </div>

      {/* Pulsing ring animation */}
      <div className="absolute inset-0 rounded-full border-2 border-primary animate-pulse" />
    </a>
  );
}
