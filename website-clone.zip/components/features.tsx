import { Truck, ShieldCheck, Headphones } from "lucide-react"

const features = [
  {
    icon: Truck,
    title: "FAST DELIVERY",
    description: "Delivery across Europe in 48-72h for urgent orders.",
  },
  {
    icon: ShieldCheck,
    title: "CERTIFIED QUALITY",
    description: "All our products are certified and traced from source to delivery.",
  },
  {
    icon: Headphones,
    title: "24/7 SUPPORT",
    description: "A dedicated team available at all times for your needs.",
  },
]

export function Features() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="flex flex-col items-center text-center p-8 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all"
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
